#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public static class CupObservationSetup
{
    [MenuItem("Tools/Cup Detection/Save Game View Evidence")]
    public static void SaveEvidence()
    {
        var monitor = Object.FindObjectOfType<CupObservationSubscriber>();
        if (!Application.isPlaying || monitor == null)
        {
            Debug.LogWarning("Enter Play Mode with the Cup numerical monitor first.");
            return;
        }
        string directory = System.IO.Path.GetFullPath(System.IO.Path.Combine(Application.dataPath,
                              "../Docs/CupDetection/Phase2M/EditorEvidence"));
        System.IO.Directory.CreateDirectory(directory);
        string basename = System.DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff");
        System.IO.File.WriteAllText(System.IO.Path.Combine(directory,basename+".txt"),monitor.Model.FormatText());
        ScreenCapture.CaptureScreenshot(System.IO.Path.Combine(directory,basename+".png"));
        Debug.Log("Cup UI screenshot requested; verify the PNG after the next rendered frame: "+directory);
    }

    [MenuItem("Tools/Cup Detection/Create Numerical Monitor")]
    public static void CreateMonitor()
    {
        if (Object.FindObjectOfType<CupObservationSubscriber>(true) != null) return;
        var host = new GameObject("CupObservationMonitor");
        Undo.RegisterCreatedObjectUndo(host,"Create cup numerical monitor");
        var canvasObject = new GameObject("Cup Numerical UI",typeof(Canvas),typeof(CanvasScaler));
        canvasObject.transform.SetParent(host.transform,false);
        var canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;
        var textObject = new GameObject("Current Cup Observations",typeof(RectTransform),typeof(Text));
        textObject.transform.SetParent(canvasObject.transform,false);
        var text = textObject.GetComponent<Text>();
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.fontSize = 18; text.color = Color.white;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.raycastTarget = false;
        var rect = text.rectTransform;
        rect.anchorMin = new Vector2(0,0); rect.anchorMax = new Vector2(1,1);
        rect.offsetMin = new Vector2(20,20); rect.offsetMax = new Vector2(-20,-20);
        var subscriber = host.AddComponent<CupObservationSubscriber>();
        subscriber.NumericalText = text;
        var preview = new GameObject("RealSense Camera Relative Preview (UNCALIBRATED)");
        preview.transform.SetParent(host.transform,false);
        subscriber.CameraFramePreviewAnchor = preview.transform;
        subscriber.ShowCameraRelativeMarkers = false;
        Selection.activeGameObject = host;
    }
}
#endif
