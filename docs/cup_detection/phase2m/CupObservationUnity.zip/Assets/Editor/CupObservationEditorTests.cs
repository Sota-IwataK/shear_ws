#if UNITY_EDITOR
using System;
using NUnit.Framework;
using RosMessageTypes.CupObservationInterfaces;
using Unity.Robotics.ROSTCPConnector.MessageGeneration;

public sealed class CupObservationEditorTests
{
    static CupObservationArrayMsg Frame(int count, double unix=1000)
    {
        var message=new CupObservationArrayMsg();
        message.header.frame_id="camera_color_optical_frame";
        message.header.stamp.sec=(int)unix;
        message.header.stamp.nanosec=(uint)((unix-Math.Floor(unix))*1e9);
        message.cup_count=count;message.observation_status="OK";
        message.observations=new CupObservationMsg[count];
        for(int i=0;i<count;i++)
        {
            var cup=new CupObservationMsg();
            cup.frame_index=(uint)i;cup.class_name="cup";cup.class_id=41;cup.confidence=.9;
            cup.bbox_xyxy=new double[]{10+i*100,20,60+i*100,90};
            cup.position_xyz_m.x=.1;cup.position_xyz_m.y=.2;cup.position_xyz_m.z=1;
            cup.position_valid=true;cup.distance_valid=true;cup.depth_z_m=1;
            cup.range_m=Math.Sqrt(1.05);cup.measurement_mode=CupObservationMsg.DIRECT;
            cup.observation_status="OK";cup.measurement_point="BODY_SURFACE";
            message.observations[i]=cup;
        }
        return message;
    }

    [TestCase(0)][TestCase(1)][TestCase(2)][TestCase(3)]
    public void RawCountAndArrayArePreserved(int count)
    {
        var state=new CupObservationViewModel();
        Assert.IsTrue(state.Apply(Frame(count),1,1,1000.01));
        Assert.AreEqual(count,state.Count);Assert.AreEqual(count,state.Rows.Count);
    }

    [Test]
    public void MissingDepthDoesNotInvalidateOtherCupOrRgb()
    {
        var message=Frame(2);message.observations[1].position_valid=false;
        message.observations[1].distance_valid=false;message.observations[1].measurement_mode=0;
        var state=new CupObservationViewModel();state.Apply(message,1,1,1000.01);
        Assert.AreEqual("OK",state.Status);Assert.IsTrue(state.Rows[0].PositionValid);
        Assert.IsFalse(state.Rows[1].PositionValid);
    }

    [Test]
    public void EdgeSampleIsNotCalledCupCentre()
    {
        var message=Frame(1);message.observations[0].measurement_mode=CupObservationMsg.EDGE_FALLBACK;
        var state=new CupObservationViewModel();state.Apply(message,1,1,1000.01);
        StringAssert.Contains("EDGE_FALLBACK",state.FormatText());
        StringAssert.Contains("lower-edge surface",state.FormatText());
    }

    [Test]
    public void OpticalAxesBecomeCameraLocalAxesWithoutWorldTranslation()
    {
        CollectionAssert.AreEqual(new[]{1.0,-2.0,3.0},CupObservationViewModel.OpticalToCameraLocal(1,2,3));
    }

    [Test]
    public void TimeoutClearsAndNewHeaderRecovers()
    {
        var state=new CupObservationViewModel();state.Apply(Frame(2),1,1,1000.01);
        state.Tick(1.6,1000.61);Assert.AreEqual("STALE",state.Status);Assert.AreEqual(0,state.Rows.Count);
        Assert.IsFalse(state.Apply(Frame(2),1.7,1.7,1000.7));
        Assert.IsTrue(state.Apply(Frame(2,1001),2,2,1001.01));
    }

    [Test]
    public void GeneratedRos2CdrRoundtripPreservesFields()
    {
        var message=Frame(2);var writer=new MessageSerializer();writer.SerializeMessage(message);
        var reader=new MessageDeserializer();reader.InitWithBuffer(writer.GetBytes());
        var decoded=CupObservationArrayMsg.Deserialize(reader);
        Assert.AreEqual(message.header.stamp.sec,decoded.header.stamp.sec);
        Assert.AreEqual(2,decoded.observations.Length);
        Assert.AreEqual(message.observations[1].range_m,decoded.observations[1].range_m);
        CollectionAssert.AreEqual(message.observations[1].bbox_xyxy,decoded.observations[1].bbox_xyxy);
    }
}
#endif
