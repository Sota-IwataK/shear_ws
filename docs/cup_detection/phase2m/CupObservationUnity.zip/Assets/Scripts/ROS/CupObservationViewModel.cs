using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using RosMessageTypes.CupObservationInterfaces;

// Pure presentation state: no identity registry, TF, Photon, or robot commands.
public sealed class CupObservationViewModel
{
    public sealed class Row
    {
        public uint FrameIndex;
        public string ClassName;
        public int ClassId;
        public double Confidence;
        public double[] BBox;
        public double[] OpticalPosition;
        public double[] CameraLocalPosition;
        public bool PositionValid;
        public bool DistanceValid;
        public double DepthZ;
        public double Range;
        public string Mode;
        public string MeasurementPoint;
    }

    public string ExpectedFrame = "camera_color_optical_frame";
    public double TimeoutSeconds = 0.5;
    public double FutureToleranceSeconds = 0.05;
    public string Status { get; private set; } = "UNKNOWN";
    public string Reason { get; private set; } = "Waiting for ROS observations";
    public string Frame { get; private set; } = "";
    public int Count { get; private set; } = -1;
    public long StampNanoseconds { get; private set; }
    public IReadOnlyList<Row> Rows => rows;
    readonly List<Row> rows = new List<Row>();
    double lastReceipt = double.NegativeInfinity;
    double sourceUnixSeconds;

    public static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    public static double[] OpticalToCameraLocal(double x, double y, double z) => new[] { x, -y, z };

    public void Invalidate(string state, string reason)
    {
        Status = state;
        Reason = reason;
        Count = -1;
        rows.Clear();
    }

    public bool Apply(CupObservationArrayMsg message, double receiptMonotonic,
                      double nowMonotonic, double nowUnixSeconds)
    {
        if (message == null || message.header == null || message.header.stamp == null)
        {
            Invalidate("UNKNOWN", "Invalid message/header");
            return false;
        }
        if (message.observation_status != "OK")
        {
            Invalidate(message.observation_status == "STALE" ? "STALE" : "UNKNOWN",
                       "ROS observation invalid");
            return false;
        }
        long stamp = (long)message.header.stamp.sec * 1000000000L + message.header.stamp.nanosec;
        double source = message.header.stamp.sec + message.header.stamp.nanosec / 1e9;
        double age = nowUnixSeconds - source;
        if (message.header.frame_id != ExpectedFrame || message.header.stamp.sec < 0
            || message.header.stamp.nanosec >= 1000000000U || stamp <= 0
            || !Finite(age) || age < -FutureToleranceSeconds || age > TimeoutSeconds
            || nowMonotonic < receiptMonotonic || nowMonotonic - receiptMonotonic > TimeoutSeconds)
        {
            Invalidate("STALE", "Wrong camera frame, expired data, or clocks not synchronized");
            return false;
        }
        if (stamp <= StampNanoseconds)
            return false; // Replayed/duplicate packets do not refresh the watchdog.
        if (message.observations == null || message.cup_count < 0
            || message.cup_count != message.observations.Length)
        {
            Invalidate("UNKNOWN", "Count/array mismatch");
            return false;
        }
        var fresh = new List<Row>();
        foreach (var cup in message.observations)
        {
            if (cup == null || cup.class_name != "cup" || cup.class_id < 0
                || !Finite(cup.confidence) || cup.confidence < 0 || cup.confidence > 1
                || cup.bbox_xyxy == null || cup.bbox_xyxy.Length != 4)
            {
                Invalidate("UNKNOWN", "Malformed cup observation");
                return false;
            }
            var box = (double[])cup.bbox_xyxy.Clone();
            if (Array.Exists(box, v => !Finite(v)) || box[0] < 0 || box[1] < 0
                || box[2] <= box[0] || box[3] <= box[1])
            {
                Invalidate("UNKNOWN", "Invalid pixel bounding box");
                return false;
            }
            bool known = cup.measurement_mode == CupObservationMsg.DIRECT
                         || cup.measurement_mode == CupObservationMsg.EDGE_FALLBACK;
            known = known && cup.observation_status != "STALE";
            var p = cup.position_xyz_m;
            bool position = known && cup.position_valid && p != null
                            && Finite(p.x) && Finite(p.y) && Finite(p.z) && p.z > 0
                            && Math.Sqrt(p.x*p.x+p.y*p.y+p.z*p.z) <= 10;
            bool distance = known && cup.distance_valid && Finite(cup.depth_z_m)
                            && Finite(cup.range_m) && cup.depth_z_m > 0
                            && cup.range_m >= cup.depth_z_m;
            if (position && distance && (Math.Abs(p.z - cup.depth_z_m) > .005
                || Math.Abs(Math.Sqrt(p.x*p.x+p.y*p.y+p.z*p.z)-cup.range_m) > .005))
                position = distance = false;
            fresh.Add(new Row {
                FrameIndex = cup.frame_index, ClassName = cup.class_name, ClassId = cup.class_id,
                Confidence = cup.confidence, BBox = box, PositionValid = position,
                OpticalPosition = position ? new[] { p.x, p.y, p.z } : null,
                CameraLocalPosition = position ? OpticalToCameraLocal(p.x,p.y,p.z) : null,
                DistanceValid = distance, DepthZ = distance ? cup.depth_z_m : 0,
                Range = distance ? cup.range_m : 0,
                Mode = !position && !distance ? "UNKNOWN" : cup.measurement_mode == CupObservationMsg.DIRECT
                       ? "DIRECT" : "EDGE_FALLBACK",
                MeasurementPoint = !position && !distance ? "unknown measurement point"
                                   : cup.measurement_mode == CupObservationMsg.EDGE_FALLBACK
                                   ? "lower-edge surface; body-distance proxy" : "sampled body surface"
            });
        }
        rows.Clear(); rows.AddRange(fresh);
        Frame = message.header.frame_id; StampNanoseconds = stamp;
        Count = message.cup_count; Status = "OK"; Reason = "Current camera-relative observations";
        lastReceipt = receiptMonotonic; sourceUnixSeconds = source;
        return true;
    }

    public void Tick(double nowMonotonic, double nowUnixSeconds)
    {
        if (Status == "OK" && (nowMonotonic - lastReceipt >= TimeoutSeconds
            || nowUnixSeconds - sourceUnixSeconds > TimeoutSeconds
            || nowUnixSeconds - sourceUnixSeconds < -FutureToleranceSeconds))
            Invalidate("STALE", "Unity watchdog: no current ROS observation");
    }

    public string FormatText()
    {
        var text = new StringBuilder();
        text.AppendLine("Cup observations — camera-relative / NOT world registered");
        text.AppendLine("Status: " + Status + "   count: " + Count + "   " + Reason);
        text.AppendLine("ROS frame: " + Frame + "   stamp(ns): " + StampNanoseconds);
        text.AppendLine("Frame indices are temporary; no blue/pink identity assignment.");
        foreach (var row in rows)
        {
            text.AppendFormat(CultureInfo.InvariantCulture, "\nframe[{0}] {1} class_id={2} confidence={3:F3}\n",
                              row.FrameIndex,row.ClassName,row.ClassId,row.Confidence);
            text.AppendFormat(CultureInfo.InvariantCulture,"BBox px [{0:F1}, {1:F1}, {2:F1}, {3:F1}]\n",
                              row.BBox[0],row.BBox[1],row.BBox[2],row.BBox[3]);
            if (row.PositionValid)
                text.AppendFormat(CultureInfo.InvariantCulture,"Optical XYZ m ({0:F3}, {1:F3}, {2:F3})\n",
                                  row.OpticalPosition[0],row.OpticalPosition[1],row.OpticalPosition[2]);
            else text.AppendLine("Optical XYZ m: UNKNOWN");
            if (row.DistanceValid)
                text.AppendFormat(CultureInfo.InvariantCulture,"Depth Z {0:F3} m   Range {1:F3} m\n",row.DepthZ,row.Range);
            else text.AppendLine("Distance: UNKNOWN");
            text.AppendLine(row.Mode + " — " + row.MeasurementPoint);
        }
        return text.ToString();
    }
}
