using System;
using System.Collections.Generic;
using System.Diagnostics;
using RosMessageTypes.CupObservationInterfaces;
using Unity.Robotics.ROSTCPConnector;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class CupObservationSubscriber : MonoBehaviour
{
    public string Topic = "/cup_detector/observations";
    public string OpticalFrame = "camera_color_optical_frame";
    [Min(.05f)] public float TimeoutSeconds = .5f;
    public Text NumericalText;
    [Tooltip("Optional camera-relative preview only. Never use an uncalibrated MR world anchor.")]
    public Transform CameraFramePreviewAnchor;
    public bool ShowCameraRelativeMarkers = false;
    public CupObservationViewModel Model { get; } = new CupObservationViewModel();
    readonly object pendingLock = new object();
    readonly List<GameObject> markers = new List<GameObject>();
    ROSConnection ros;
    CupObservationArrayMsg pending;
    double pendingReceipt;
    bool subscribed;
    static double MonoNow => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
    static double UnixNow => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0;

    void OnEnable()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<CupObservationArrayMsg>(Topic, Receive);
        subscribed = true;
    }

    // The callback only hands off data. Unity object/UI access stays in Update.
    void Receive(CupObservationArrayMsg value)
    {
        lock (pendingLock) { pending = value; pendingReceipt = MonoNow; }
    }

    void Update()
    {
        Model.ExpectedFrame = OpticalFrame;
        Model.TimeoutSeconds = TimeoutSeconds;
        CupObservationArrayMsg value;
        double receipt;
        lock (pendingLock) { value = pending; receipt = pendingReceipt; pending = null; }
        if (value != null) Model.Apply(value,receipt,MonoNow,UnixNow);
        if (ros != null && ros.HasConnectionError)
            Model.Invalidate("STALE", "ROS-TCP disconnected or reconnecting");
        Model.Tick(MonoNow,UnixNow);
        if (NumericalText != null) NumericalText.text = Model.FormatText();
        UpdateMarkers();
    }

    void UpdateMarkers()
    {
        foreach (var marker in markers) marker.SetActive(false);
        if (!ShowCameraRelativeMarkers || CameraFramePreviewAnchor == null || Model.Status != "OK") return;
        var scale = CameraFramePreviewAnchor.lossyScale;
        if ((scale - Vector3.one).sqrMagnitude > 1e-6f) return; // Metres require unit scale.
        for (int i = 0; i < Model.Rows.Count; i++)
        {
            var row = Model.Rows[i];
            if (!row.PositionValid) continue;
            while (markers.Count <= i)
            {
                var marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                marker.name = "Cup sampled surface (frame-local preview)";
                var collider = marker.GetComponent<Collider>();
                if (collider != null) { collider.enabled = false; Destroy(collider); }
                markers.Add(marker);
            }
            var target = markers[i];
            target.transform.SetParent(CameraFramePreviewAnchor,false);
            var p = row.CameraLocalPosition;
            target.transform.localPosition = new Vector3((float)p[0],(float)p[1],(float)p[2]);
            target.transform.localScale = Vector3.one * .025f;
            target.SetActive(true);
        }
    }

    void OnDisable()
    {
        if (subscribed && ros != null) ros.Unsubscribe(Topic);
        subscribed = false;
        lock (pendingLock) pending = null;
        Model.Invalidate("UNKNOWN", "Subscriber disabled");
        if (NumericalText != null) NumericalText.text = Model.FormatText();
        foreach (var marker in markers) if (marker != null) Destroy(marker);
        markers.Clear();
    }
}
