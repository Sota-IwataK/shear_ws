# 別PC Unity Editor 統合確認記録

状態: **未実施 / HOLD**。実施日・PC・Editor版・結果を実施時に記入する。
このファイルはテスト成功の証拠ではない。

対象: SHARE / Unity 2022.3.62f2 / 既存ROS-TCP-Connector v0.7.1。
操作は [INSTALL_UNITY.md](INSTALL_UNITY.md) に従う。
Linux側は今回の実験processを停止しているため、再度診断系を起動する。

| 確認 | 結果 | 必要な証拠 |
|---|---|---|
| 新ファイルimport・Console compileエラー0 | 未確認 | Editor.log、Console |
| 新9ケースと既存EditMode回帰 FAIL0 | 未確認 | Test Runner XML |
| A: 1 Cup | 未確認 | 同じstampのROS echoとGame View |
| B: 2 Cup | 未確認 | 配列数、class/BBox/confidence/XYZ/Z/Range/方式の一致 |
| C: 0 Cup | 未確認 | OK/count0、旧行・markerなし |
| D: 1 CupのみDepth有効 | 未確認 | RGB count2、片方UNKNOWN |
| E: EDGE_FALLBACK | 未確認 | 下縁表面・proxy label、中心へ移動していない |
| F: cameraだけ停止 | 未確認 | STALE/count-1、旧位置非表示、経過秒 |
| G: ROS-TCP切断・再接続 | 未確認 | 通信断timeout、新stampで復旧、古いpacket非表示 |
| 数値UI確認後のcamera相対marker | 未確認 | unit-scale Anchorと軸方向の確認 |
| Bottle表示など既存機能の回帰 | 未確認 | 既存表示/テストの結果 |
| source stamp→Unity UI更新遅延 | 未測定 | 時計同期、計測点、P95、標本数 |

人工A〜Gと実機A/B/C・実際の欠測/下縁の両方を確認する。
fixtureを使用する時は本運用domainを使わない。
画面保存メニューが作るPNG/TXTを `Docs/CupDetection/Phase2M/EditorEvidence/` に残す。
PNGに実際のUIが写っていることを確認する。カメラ原画像をEditor画面証拠として使わない。
数値TXTとPNGは隣接frameで作成される場合があるため、比較は表示stampで照合する。

未校正のAnchor位置をMR world座標とみなさない。
indexによる青/薄桃の恒久ID付与、BottleIdentityKey/FSMやPhotonへの接続は対象外。
全確認の証拠が揃うまでPhase2M全体をPASSにしない。
