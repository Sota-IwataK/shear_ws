# 別PCのUnity Editorでの確認

対象は既存SHARE、Unity2022.3.62f2、ROS-TCP-Connector0.7.1。
新しいnetwork bridgeやPhoton送信は追加しない。

1. `CupObservationUnity.zip` の `Assets/` と `Docs/` を別PCのSHAREルートへコピーする。
   追加ファイルだけのarchive。既存scene/ProjectSettings/Packages/Bottleコードは含まない。
2. Unityでimport/compileを完了し、Consoleのエラーを確認する。
   既存のStandalone/Android設定に `ROS2` があることを確認する。
3. Linux側で後述のROS launchを起動し、**既存**ROS Settingsの接続先をLinuxのLAN IP・port10000へ設定。
   既存endpointを使う場合は新msgのoverlayをsourceして起動されていることが必要。
   2つ目のendpointを同じportへ追加しない。
4. 両PCのUTC時刻を同期する。Unityはsource stampのageを検査し、時計がずれていれば
   STALEにする。過去の録画を新しい観測へ偽装する時刻置換は行わない。
5. `Tools > Cup Detection > Create Numerical Monitor` を選択し、Play Modeに入る。
   `OpticalFrame=camera_color_optical_frame`、timeout0.5秒が既定。
6. class/id/confidence/BBox、camera optical XYZ、Depth Z、Range、DIRECT/EDGE_FALLBACK/UNKNOWNを確認する。
   RGB有効・Depth無効のCupも配列には残る。ゼロ座標は無効値のplaceholderで、UIはUNKNOWNと表示する。
7. Test RunnerのEditModeで `CupObservationEditorTests` と既存テストを実行する。
   Linuxで実行した.NET検証はUnity Editorのcompile/render/regressionの代用ではない。
8. 数値UIを確認した後、必要ならInspectorの `ShowCameraRelativeMarkers` を有効にする。
   `CameraFramePreviewAnchor` 配下のlocal positionは `(ros.x,-ros.y,ros.z)`、単位m。
   Anchorのscaleは1。これは未校正のcamera相対previewで、MR world registrationではない。
   下縁のpointは下縁のpointとして表示し、Cup中心には移動しない。
9. `Tools > Cup Detection > Save Game View Evidence` を選ぶ。
   次の描画frame後に `Docs/CupDetection/Phase2M/EditorEvidence/` のPNGとTXTを確認する。
   この操作は別PCで必要。現時点でEditorスクリーンショットは未取得。

## Linuxの起動

新2packageをbuildした後、既存のPhase2K CPU環境を使用する。

```bash
cd /home/dars-note-5070/iwata_ws/shear_ws
source /opt/ros/humble/setup.bash
colcon --log-base /tmp/cup-phase2m-colcon-log-verified build \
  --base-paths src/cup_observation_interfaces src/cup_observation_bridge \
  --build-base /tmp/cup-phase2m-build --install-base /tmp/cup-phase2m-install
export ROS_DOMAIN_ID=167
export CUP_VIS_TCP_BIND=0.0.0.0
bash docs/cup_detection/phase2m/run_visualization_ros.sh
```

既存camera/認識/endpointを再利用する場合は、該当する
`CUP_VIS_REUSE_CAMERA=1`、`CUP_VIS_REUSE_DETECTOR=1`、`CUP_VIS_REUSE_ENDPOINT=1` を指定する。
launcherは再利用したprocessを停止しない。旧認識QoS・重み・閾値の本運用設定は変更しない。
既定のloopback bindでは別PCから接続できないため、別PC検証時だけLAN bindを明示する。

## Editorで残っている統合確認

A 1 Cup、B 2 Cup、C 0 Cup、D 1個のみDepth、E EDGE_FALLBACK、
F cameraだけ停止、G endpoint切断/再接続を確認する。
ROS出力と同じheaderの値を比較し、通信断では0.5秒程度で数値/markerが無効になること、
新しい観測で復旧することを記録する。異なるframeのcountとpositionを比較しない。
検出indexはframe内の表示番号だけで、青/薄桃の恒久IDにはしない。

カメラ→Unity worldのTF/Anchor registrationは未校正。Quest/Photon共有は本Phaseの対象外。
