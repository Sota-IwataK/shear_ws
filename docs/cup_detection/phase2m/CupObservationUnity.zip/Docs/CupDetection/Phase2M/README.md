# Cup visualization Phase2M

Status: HOLD — actual Unity Editor validation is pending.

Read INSTALL_UNITY.md and record REMOTE_CHECKLIST.md.
This archive adds Cup assets only. Existing scenes, packages, Bottle, FSM and Identity files are omitted.
The source of truth is the ROS observation, in camera optical frame and metres.
Frame indices are temporary. EDGE_FALLBACK is a sampled lower edge, not a cup centre.
No world registration or Photon sharing is included.

Full Linux report: docs/cup_detection/phase2m/REPORT.md in shear_ws.
